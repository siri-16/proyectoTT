package com.tokenizer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokenizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
