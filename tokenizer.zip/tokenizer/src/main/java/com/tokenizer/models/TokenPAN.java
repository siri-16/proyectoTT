/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author rirll
 */
@Entity
@Table(name = "Token_PAN")
@NamedQueries({
    @NamedQuery(name = "TokenPAN.findAll", query = "SELECT t FROM TokenPAN t")})
public class TokenPAN implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected TokenPANPK tokenPANPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 16)
    @Column(name = "token")
    private String token;
    @Basic(optional = false)
    @NotNull
    @Column(name = "vigencia")
    private boolean vigencia;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaActualizacion")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaActualizacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCreacion")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCreacion;
    @JoinColumn(name = "rfc", referencedColumnName = "rfc", insertable = false, updatable = false)
    @JsonIgnore
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Cliente cliente;

    public TokenPAN() {
    }

    public TokenPAN(TokenPANPK tokenPANPK) {
        this.tokenPANPK = tokenPANPK;
    }

    public TokenPAN(TokenPANPK tokenPANPK, String token, boolean vigencia, Date fechaActualizacion, Date fechaCreacion) {
        this.tokenPANPK = tokenPANPK;
        this.token = token;
        this.vigencia = vigencia;
        this.fechaActualizacion = fechaActualizacion;
        this.fechaCreacion = fechaCreacion;
    }

    public TokenPAN(String rfc, String pan) {
        this.tokenPANPK = new TokenPANPK(rfc, pan);
    }

    public TokenPANPK getTokenPANPK() {
        return tokenPANPK;
    }

    public void setTokenPANPK(TokenPANPK tokenPANPK) {
        this.tokenPANPK = tokenPANPK;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public boolean getVigencia() {
        return vigencia;
    }

    public void setVigencia(boolean vigencia) {
        this.vigencia = vigencia;
    }

    public Date getFechaActualizacion() {
        return fechaActualizacion;
    }

    public void setFechaActualizacion(Date fechaActualizacion) {
        this.fechaActualizacion = fechaActualizacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tokenPANPK != null ? tokenPANPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TokenPAN)) {
            return false;
        }
        TokenPAN other = (TokenPAN) object;
        if ((this.tokenPANPK == null && other.tokenPANPK != null) || (this.tokenPANPK != null && !this.tokenPANPK.equals(other.tokenPANPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tokenizer.models.TokenPAN[ tokenPANPK=" + tokenPANPK + " ]";
    }
    
}
