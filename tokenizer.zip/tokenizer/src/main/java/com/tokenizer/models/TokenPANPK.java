/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.models;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author rirll
 */
@Embeddable
public class TokenPANPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 18)
    @Column(name = "rfc")
    private String rfc;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 16)
    @Column(name = "pan")
    private String pan;

    public TokenPANPK() {
    }

    public TokenPANPK(String rfc, String pan) {
        this.rfc = rfc;
        this.pan = pan;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rfc != null ? rfc.hashCode() : 0);
        hash += (pan != null ? pan.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TokenPANPK)) {
            return false;
        }
        TokenPANPK other = (TokenPANPK) object;
        if ((this.rfc == null && other.rfc != null) || (this.rfc != null && !this.rfc.equals(other.rfc))) {
            return false;
        }
        if ((this.pan == null && other.pan != null) || (this.pan != null && !this.pan.equals(other.pan))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tokenizer.models.TokenPANPK[ rfc=" + rfc + ", pan=" + pan + " ]";
    }
    
}
