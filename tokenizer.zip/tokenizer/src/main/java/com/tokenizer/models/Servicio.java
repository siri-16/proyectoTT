/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author rirll
 */
@Entity
@Table(name = "Servicio")
@NamedQueries({
    @NamedQuery(name = "Servicio.findAll", query = "SELECT s FROM Servicio s")})
public class Servicio implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ServicioPK servicioPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 500)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "tipoServicio")
    private String tipoServicio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaActualizacion")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaActualizacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaCreacion")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCreacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "habilitado")
    private boolean habilitado;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "algoritmo")
    private String algoritmo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "cifrado")
    private String cifrado;
    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "contrato")
    private byte[] contrato;
    @Basic(optional = false)
    @NotNull
    @Column(name = "costoServicioAnual")
    private double costoServicioAnual;
    @JoinColumn(name = "rfc", referencedColumnName = "rfc", insertable = false, updatable = false)
    @JsonIgnore
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private Cliente cliente;

    public Servicio() {
    }

    public Servicio(ServicioPK servicioPK) {
        this.servicioPK = servicioPK;
    }

    public Servicio(ServicioPK servicioPK, String descripcion, String tipoServicio, Date fechaActualizacion, Date fechaCreacion, boolean habilitado, String algoritmo, String cifrado, byte[] contrato, double costoServicioAnual) {
        this.servicioPK = servicioPK;
        this.descripcion = descripcion;
        this.tipoServicio = tipoServicio;
        this.fechaActualizacion = fechaActualizacion;
        this.fechaCreacion = fechaCreacion;
        this.habilitado = habilitado;
        this.algoritmo = algoritmo;
        this.cifrado = cifrado;
        this.contrato = contrato;
        this.costoServicioAnual = costoServicioAnual;
    }

    public Servicio(String rfc, String numeroContrato) {
        this.servicioPK = new ServicioPK(rfc, numeroContrato);
    }

    public ServicioPK getServicioPK() {
        return servicioPK;
    }

    public void setServicioPK(ServicioPK servicioPK) {
        this.servicioPK = servicioPK;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public void setTipoServicio(String tipoServicio) {
        this.tipoServicio = tipoServicio;
    }

    public Date getFechaActualizacion() {
        return fechaActualizacion;
    }

    public void setFechaActualizacion(Date fechaActualizacion) {
        this.fechaActualizacion = fechaActualizacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public boolean getHabilitado() {
        return habilitado;
    }

    public void setHabilitado(boolean habilitado) {
        this.habilitado = habilitado;
    }

    public String getAlgoritmo() {
        return algoritmo;
    }

    public void setAlgoritmo(String algoritmo) {
        this.algoritmo = algoritmo;
    }

    public String getCifrado() {
        return cifrado;
    }

    public void setCifrado(String cifrado) {
        this.cifrado = cifrado;
    }

    public byte[] getContrato() {
        return contrato;
    }

    public void setContrato(byte[] contrato) {
        this.contrato = contrato;
    }

    public double getCostoServicioAnual() {
        return costoServicioAnual;
    }

    public void setCostoServicioAnual(double costoServicioAnual) {
        this.costoServicioAnual = costoServicioAnual;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (servicioPK != null ? servicioPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Servicio)) {
            return false;
        }
        Servicio other = (Servicio) object;
        if ((this.servicioPK == null && other.servicioPK != null) || (this.servicioPK != null && !this.servicioPK.equals(other.servicioPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tokenizer.models.Servicio[ servicioPK=" + servicioPK + " ]";
    }
    
}
