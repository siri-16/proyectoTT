/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.services;

import com.tokenizer.models.Cliente;
import com.tokenizer.repositories.ClienteRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author rirll
 */
@Service
public class ClienteService {
    
    @Autowired 
    private ClienteRepository clienteRepository;
    
    public Cliente crearCliente(Cliente cliente){
        //VERIFICAR SI YA ESTÁ REGISTRADO EL RFC DE cliente
        Optional<Cliente> clienteExistente= this.clienteRepository.findById(cliente.getRfc());
        if(clienteExistente.isPresent() || !clienteExistente.isEmpty()){
            throw new IllegalArgumentException("CLIENTE EXISTENTE CON EL RFC DADO");
        }
        
        //ATRIBUTOS DE CLIENTE
        Cliente nuevoCliente= new Cliente(cliente.getRfc()); /*Inicializar Cliente con RFC*/
        nuevoCliente.setFechaCreacion(new Date());
        nuevoCliente.setFechaActualizacion(new Date());
        nuevoCliente.setHabilitado(true);
        nuevoCliente.setDescripcion(cliente.getDescripcion());
        
        //ATRIBUTOS DE USUARIO
        //VERIFICAR QUE HAYA AL MENOS UN USUARIO
        nuevoCliente.setUsuarioList(null);
        
        //ATRIBUTOS TIPO CLIENTE (Agregar atributo TipoCliente boolean 1 persona, 0 comercio)
        nuevoCliente.setPersona(null);
        nuevoCliente.setComercio(null);
        
        //ATRIBUTOS DE DIRECCION
        nuevoCliente.setDireccionList(null);
        
        //ATRIBUTOS DE SERVICIO
        nuevoCliente.setServicioList(null);
        
        //ATRIBUTOS DE PANS/TOKENS
        nuevoCliente.setTokenPANList(null);
        
        this.clienteRepository.save(nuevoCliente);
        return nuevoCliente;
        //return clienteRepository.save(cliente);
    }
    
    public Cliente registrarCliente(Cliente cliente){
        //VERIFICAR SI YA ESTÁ REGISTRADO EL RFC DE cliente
        Optional<Cliente> clienteExistente= this.clienteRepository.findById(cliente.getRfc());
        if(clienteExistente.isPresent() || !clienteExistente.isEmpty()){
            throw new IllegalArgumentException("CLIENTE EXISTENTE CON EL RFC DADO");
        }
        
        //ATRIBUTOS DE CLIENTE
        Cliente nuevoCliente= new Cliente(cliente.getRfc()); /*Inicializar Cliente con RFC*/
        nuevoCliente.setFechaCreacion(new Date());
        nuevoCliente.setFechaActualizacion(new Date());
        nuevoCliente.setHabilitado(true);
        nuevoCliente.setDescripcion(cliente.getDescripcion());
        
        //ATRIBUTOS DE USUARIO
        //VERIFICAR QUE HAYA AL MENOS UN USUARIO
        nuevoCliente.setUsuarioList(cliente.getUsuarioList());
        
        //ATRIBUTOS TIPO CLIENTE 
        if(cliente.getPersona()!= null ){
            nuevoCliente.setPersona(cliente.getPersona());
            nuevoCliente.setComercio(null);
        }
        
        if(cliente.getComercio()!=null){
            nuevoCliente.setComercio(cliente.getComercio());
            nuevoCliente.setPersona(null);
        }
        
        //ATRIBUTOS DE DIRECCION
        nuevoCliente.setDireccionList(cliente.getDireccionList());
        
        
        //ATRIBUTOS DE SERVICIO
        nuevoCliente.setServicioList(null);
        
        //ATRIBUTOS DE PANS/TOKENS
        nuevoCliente.setTokenPANList(null);
        
        this.clienteRepository.save(nuevoCliente);
        return nuevoCliente;
        //return clienteRepository.save(cliente);
    }
    
    public ArrayList<Cliente> listarClientes() throws Exception{
        // LISTAR CLIENTES, INCLUSO CLINTES "ELIMINADOS"
        //return (ArrayList<Cliente>) clienteRepository.findAll();
        
        // LISTAS CLIENTES HABILITADOS
        ArrayList<Cliente> listaClientes= clienteRepository.findByHabilitado(true);
        if(listaClientes.isEmpty()){
            throw new IllegalArgumentException("SIN CLIENTES");
        }
        for(Cliente cliente:listaClientes){
            if(cliente.getUsuarioList()!=null){
                cliente.setUsuarioList(null);
            }
        }
        
        for(Cliente cliente:listaClientes){
            if(cliente.getDireccionList()!=null){
                cliente.setDireccionList(null);
            }
        }
        
        for(Cliente cliente:listaClientes){
            if(cliente.getServicioList()!=null){
                cliente.setServicioList(null);
            }
        }
        
        for(Cliente cliente:listaClientes){
            if(cliente.getTokenPANList()!=null){
                cliente.setTokenPANList(null);
            }
        }
        
        for(Cliente cliente:listaClientes){
            if(cliente.getComercio()!=null){
                cliente.setComercio(null);
            }
        }
        
        for(Cliente cliente:listaClientes){
            if(cliente.getPersona()!=null){
                cliente.setPersona(null);
            }
        }
        
        return (ArrayList<Cliente>) clienteRepository.findByHabilitado(true);
    }

    public Cliente obtenerClientePorId(String id) throws Exception{
        Cliente cliente= this.clienteRepository.findByRfcAndHabilitado(id, true);
        
        if(cliente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        return cliente;
    }

    public Cliente actualizarCliente(String rfc, Cliente clienteActualizado) throws Exception{
        Cliente cliente = this.clienteRepository.findByRfc(rfc);
        if(cliente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
       Cliente result= new Cliente(
               clienteActualizado.getRfc(), 
               clienteActualizado.getDescripcion(),
               cliente.getFechaCreacion(),
               clienteActualizado.getHabilitado(), 
               new Date()
        );
       this.clienteRepository.save(result);
       
        return result;
    }
    

    public Cliente eliminarClientePorId(String rfc) throws Exception{
        Cliente cliente = this.clienteRepository.findByRfc(rfc);
        if(cliente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VERIFICAR QUE CLIENTE QUE SE DESEA ELIMINAR ESTÁ ACTIVO
        Cliente clienteEliminar= this.clienteRepository.findByRfcAndHabilitado(rfc,true);
        if(clienteEliminar==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        clienteEliminar.setHabilitado(false);
        clienteRepository.save(clienteEliminar);
        
        return clienteEliminar;
    }
    
    /*public ArrayList<Cliente>  obtenerClientesHabilitados(Boolean habilitado) {
    return clienteRepository.findByHabilitado(habilitado);
    }*/
    
    
}
