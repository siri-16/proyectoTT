/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.services;

import com.tokenizer.models.Cliente;
import com.tokenizer.models.TokenPAN;
import com.tokenizer.repositories.ClienteRepository;
import com.tokenizer.repositories.ServicioRepository;
import com.tokenizer.repositories.TokenPanRepository;
import java.util.Date;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author rirll
 */
@Service
public class TokenPanService{
    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    private ServicioRepository servicioRepository;
    @Autowired
    private TokenPanRepository tokenPanRepository;
    
    public TokenPAN crearToken(String pan, Date date, Cliente cliente){
    //VERIFICAR EXISTENCIA DE CLIENTE    
    //VERIFICAR EL TIPO DE SERVICIO IF ES TKR POR EJEMPLO

    //VERIFICAR EN LA BASE DE DATOS DE TOKEN SI EXISTE YA EL PAN
        Optional<TokenPAN> panExistente= this.tokenPanRepository.findByTokenPANPKPan(pan);
    //VERIFICAR EN LA BASE DE DATOS SI YA ESTÁ ESE DATO ASOCIADO(FECHA)
        Optional<TokenPAN> fechaCExistente=this.tokenPanRepository.findByFechaCreacion(date);
        if((panExistente.isEmpty() || !panExistente.isPresent()) && (fechaCExistente.isEmpty() || !fechaCExistente.isPresent())){
            //CALCULAR TOKEN
            TokenPAN tokenpan= new TokenPAN(cliente.getRfc(), pan);
            return tokenpan;
        }
    
    //OBTENER EL PAN Y TOKEN GUARDADOS
        TokenPAN tokenpanE= this.tokenPanRepository.findByTokenPANPKRfcAndTokenPANPKPan(cliente.getRfc(), pan);
        
    //Optional<TokenPAN> tokenExistente= this.tokenPanRepository.findByToken(pan);
        return tokenpanE;
    }
    
//    public TokenPAN obtenerPan(){
//    
//    }
}
