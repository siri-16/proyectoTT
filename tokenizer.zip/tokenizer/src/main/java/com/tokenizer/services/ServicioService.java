/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.services;

import com.tokenizer.models.Cliente;
import com.tokenizer.models.Servicio;
import com.tokenizer.models.ServicioPK;
import com.tokenizer.repositories.ClienteRepository;
import com.tokenizer.repositories.ServicioRepository;
import java.security.SecureRandom;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author rirll
 */
@Service
public class ServicioService {
    @Autowired
    private ClienteRepository clienteRepository;
    
    @Autowired
    private ServicioRepository servicioRepository;
    
    public Servicio crearServicio(String rfc, Servicio servicio){
        //VERIFICAR SI RFC EXISTE, ES DECIR, SI EXISTE EL CLIENTE
        Optional<Cliente> cliente=this.clienteRepository.findById(rfc);
        if(cliente.isEmpty() || !cliente.isPresent()){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VALIDAR SI CLIENTE ESTÁ HABILITADO
        Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
        if(clienteExistente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VERIFICAR SI YA EXISTE SERVICIO CON EL NUMERO DE CONTRATO DE "servicio"
        Optional<Servicio> servicio1=this.servicioRepository.findByServicioPKNumeroContrato(servicio.getServicioPK().getNumeroContrato());
        if(servicio1.isPresent() || !servicio1.isEmpty()){
            throw new IllegalArgumentException("GIVEN numero de contrado ALREADY EXIST");
        }
        
        //GENERAR NUMERO DE CONTRATO
        Long noContrato= new SecureRandom().nextLong();
        String noDeContrato= noContrato.toString().substring(0, 16);
        
        //GENERAR BINARIO
        byte[] contratoByte= servicio.getDescripcion().getBytes();
        
        ServicioPK nuevoSPK= new ServicioPK(rfc, noDeContrato);
        Servicio nuevoServicio= new Servicio(
                nuevoSPK,
                servicio.getDescripcion(),
                servicio.getTipoServicio(),
                new Date(),
                new Date(),
                true,
                servicio.getAlgoritmo(),
                servicio.getCifrado(),
                contratoByte,
                servicio.getCostoServicioAnual()
        );
        
        //PERSISTIR USUARIO
        this.servicioRepository.save(nuevoServicio);
        
        return nuevoServicio;
    }
    
    public List<Servicio> listarServicios(String rfc) throws Exception{
            //VALIDAR SI EL CLIENTE CON ESE RFC EXISTE
            Optional<Cliente> cliente=this.clienteRepository.findById(rfc);
            if(cliente.isEmpty() || !cliente.isPresent()){
                throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
            }
            
            //VALIDAR SI CLIENTE ESTÁ HABILITADO
            Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
            if(clienteExistente==null){
                throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
            }
            
            List<Servicio> servicios= this.servicioRepository.findByServicioPKRfc(rfc);
            // VALIDAR SI EL CLIENTE TIENE SERVICIOS
            if(servicios.isEmpty()){
                throw new IllegalArgumentException("ESTE CLIENTE NO TIENE SERVICIOS");
            }
            
            if (servicios != null && !servicios.isEmpty()) {
                servicios.forEach(servicio -> {
                    servicio.setCliente(null);
                });
            }

            return servicios;
        }
    
}
