/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.services;

import com.tokenizer.models.Cliente;
import com.tokenizer.models.Direccion;
import com.tokenizer.models.DireccionPK;
import com.tokenizer.repositories.ClienteRepository;
import com.tokenizer.repositories.DireccionRepository;
import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author rirll
 */
@Service
public class DireccionService {
    @Autowired
    private ClienteRepository clienteRepository;
    
    @Autowired
    private DireccionRepository direccionRepository;
    
        public Direccion crearDireccion(String rfc, Direccion direccion) throws Exception{
            //VERIFICAR SI RFC DE CLIENTE EXISTE
            Optional<Cliente> cliente=this.clienteRepository.findById(rfc);
            if(cliente.isEmpty() || !cliente.isPresent()){
                throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
            }
            
            //VALIDAR SI CLIENTE ESTÁ HABILITADO
            Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
            if(clienteExistente==null){
                throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
            }
            
            //VERIFICAR SI YA FUE REGISTRADA ESA DIRECCIÓN
            Optional<Direccion> direccion1 =this.direccionRepository.findByDireccionPKIdDireccion(direccion.getDireccionPK().getRfc());
            if(direccion1.isPresent() || !direccion1.isEmpty()){
                throw new IllegalArgumentException("GIVEN direccion ALREADY EXIST");
            }
            
            Long id= new SecureRandom().nextLong();
            String idDireccion= id.toString().substring(0, 16);
            System.out.println("ID"+idDireccion);
            
            DireccionPK direccionPKN= new DireccionPK(rfc, idDireccion);
            Direccion direccionNueva= new Direccion(direccionPKN,
                    direccion.getEstado(),
                    direccion.getDelegacionMunicipio(),
                    direccion.getCodigoPostal(),
                    direccion.getNumero(),
                    direccion.getCalle());
            
            this.direccionRepository.save(direccionNueva);
            
            return direccionNueva;
        }
        
        public List<Direccion> listarDirecciones(String rfc) throws Exception{
            //VALIDAR SI EL CLIENTE CON ESE RFC EXISTE
            Optional<Cliente> cliente=this.clienteRepository.findById(rfc);
            if(cliente.isEmpty() || !cliente.isPresent()){
                throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
            }
            
            //VALIDAR SI CLIENTE ESTÁ HABILITADO
            Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
            if(clienteExistente==null){
                throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
            }
            
            List<Direccion> direcciones= this.direccionRepository.findByDireccionPKRfc(rfc) ;
            // VALIDAR SI EL CLIENTE TIENE USUARIOS
            if(direcciones.isEmpty()){
                throw new IllegalArgumentException("ESTE CLIENTE NO TIENE DIRECCIONES");
            }

            if (direcciones != null && !direcciones.isEmpty()) {
                direcciones.forEach(direccion -> {
                    direccion.setCliente(null);
                });
            }

            return direcciones;
        }

}