/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.services;

import com.tokenizer.models.Cliente;
import com.tokenizer.models.Usuario;
import com.tokenizer.models.UsuarioPK;
import com.tokenizer.repositories.ClienteRepository;
import com.tokenizer.repositories.UsuarioRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author rirll
 */
@Service
public class UsuarioService {
    @Autowired
    private ClienteRepository clienteRepository;
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    //CREAR USUARIOS
    public Usuario crearUsuario(String rfc, Usuario usuario) throws Exception{
        //VERIFICAR SI RFC EXISTE, ES DECIR, SI EXISTE EL CLIENTE
        Optional<Cliente> cliente=this.clienteRepository.findById(rfc);
        if(cliente.isEmpty() || !cliente.isPresent()){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VALIDAR SI CLIENTE ESTÁ HABILITADO
        Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
        if(clienteExistente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VERIFICAR YA SI EXISTE USUARIO CON ESE NOMBRE DE USUARIO
        Optional<Usuario> usuario1=this.usuarioRepository.findByUsuarioPKNombreUsuario(usuario.getUsuarioPK().getNombreUsuario());
        if(usuario1.isPresent() || !usuario1.isEmpty()){
            throw new IllegalArgumentException("GIVEN nombreUsuario ALREADY EXIST");
        }
        
        UsuarioPK nuevoUPK= new UsuarioPK(rfc, usuario.getUsuarioPK().getNombreUsuario());
        Usuario nuevoUsuario= new Usuario(nuevoUPK);
        nuevoUsuario.setContrasenia(usuario.getContrasenia());
        nuevoUsuario.setEmail(usuario.getEmail());
        
        //PERSISTIR USUARIO
        this.usuarioRepository.save(nuevoUsuario);
        
        return nuevoUsuario;
    }
    
    //LISTAR TODOS LOS USUARIOS
    public ArrayList<Usuario> listarUsuarios()throws Exception{
        ArrayList<Usuario> usuarios= (ArrayList<Usuario>) this.usuarioRepository.findAll() ;
        if(usuarios.isEmpty()){
            throw new IllegalArgumentException("SIN USUARIOS");
        }
        
        if (usuarios != null && !usuarios.isEmpty()) {
            for (Usuario usuario: usuarios) {
                usuario.setCliente(null);
            }
        }
        
        return usuarios;
    }
    
    //LISTAR TODOS LOS USUARIOS DE UN CLIENTE
    public List<Usuario> listarUsuariosId(String rfc)throws Exception{
        //VALIDAR SI CLIENTE EXISTE, ES DECIR, QUE SU RFC ESTÁ REGISTRADO
        Optional<Cliente> cliente= this.clienteRepository.findById(rfc);
        if(cliente.isEmpty() || !cliente.isPresent()){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VALIDAR SI CLIENTE ESTÁ HABILITADO
        Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
        if(clienteExistente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        List<Usuario> usuarios= this.usuarioRepository.findByUsuarioPKRfc(rfc);
        // VALIDAR SI EL CLIENTE TIENE USUARIOS
        if(usuarios.isEmpty()){
            throw new IllegalArgumentException("ESTE CLIENTE NO TIENE USUARIOS REGISTRADOS");
        }
        
        if (usuarios != null && !usuarios.isEmpty()) {
            usuarios.forEach(usuario -> {
                usuario.setCliente(null);
            });
        }
        
        return usuarios;
    }

}
