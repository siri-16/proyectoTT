/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.services;

import com.tokenizer.models.Cliente;
import com.tokenizer.models.Persona;
import com.tokenizer.repositories.ClienteRepository;
import com.tokenizer.repositories.PersonaRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author rirll
 */
@Service
public class PersonaService {
    @Autowired
    private ClienteRepository clienteRepository;
    
    @Autowired
    private PersonaRepository personaRepository;
    
    public Persona crearPersona(String rfc, Persona persona)throws Exception{
        //VERIFICAR SI RFC EXISTE, ES DECIR, SI EXISTE EL CLIENTE
        Optional<Cliente> cliente=this.clienteRepository.findById(rfc);
        if(cliente.isEmpty() || !cliente.isPresent()){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VALIDAR SI CLIENTE ESTÁ HABILITADO
        Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
        if(clienteExistente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        Persona nuevaPersona= new Persona(
            rfc,
            persona.getPrimerNombre(),
            persona.getApellidoPaterno(),
            persona.getApellidoMaterno()
        );
        
        if(persona.getSegundoNombre()!=null){
            nuevaPersona.setSegundoNombre(persona.getSegundoNombre());
        }
        
        //PERSISTENCIA DE NUEVA PERSONA
        this.personaRepository.save(nuevaPersona);
        
        return nuevaPersona;
    }
    
    public Persona mostrarPersona(String rfc){
        //VALIDAR SI CLIENTE EXISTE, ES DECIR, QUE SU RFC ESTÁ REGISTRADO
        Optional<Cliente> cliente= this.clienteRepository.findById(rfc);
        if(cliente.isEmpty() || !cliente.isPresent()){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VALIDAR SI CLIENTE ESTÁ HABILITADO
        Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
        if(clienteExistente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        Persona persona= this.personaRepository.findByRfc(rfc) ;
        //VALIDAR SI EL CLIENTE ES PERSONA
        if(persona==null){
            throw new IllegalArgumentException("ESTE CLIENTE NO ES PERSONA");
        }
        
        persona.setCliente(null);
        
        return persona;
    }
}
