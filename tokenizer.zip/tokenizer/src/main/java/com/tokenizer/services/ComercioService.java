/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.services;

import com.tokenizer.models.Cliente;
import com.tokenizer.models.Comercio;
import com.tokenizer.repositories.ClienteRepository;
import com.tokenizer.repositories.ComercioRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author rirll
 */
@Service
public class ComercioService {
    
    @Autowired
    private ClienteRepository clienteRepository;
    
    @Autowired
    private ComercioRepository comercioRepository;
    
    public Comercio crearComercio(String rfc, Comercio comercio)throws Exception{
        //VERIFICAR SI RFC EXISTE, ES DECIR, SI EXISTE EL CLIENTE
        Optional<Cliente> cliente=this.clienteRepository.findById(rfc);
        if(cliente.isEmpty() || !cliente.isPresent()){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VALIDAR SI CLIENTE ESTÁ HABILITADO
        Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
        if(clienteExistente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        Comercio nuevoComercio= new Comercio(
            rfc,
            comercio.getRegimen(),
            comercio.getRazonSocial(),
            comercio.getNombreComercio(),
            comercio.getSucursal()
        );
        
        //PERSISTENCIA DE NUEVO COMERCIO
        this.comercioRepository.save(nuevoComercio);

        return nuevoComercio;
    }
    
    public Comercio mostrarComercios(String rfc){
        //VALIDAR SI CLIENTE EXISTE, ES DECIR, QUE SU RFC ESTÁ REGISTRADO
        Optional<Cliente> cliente= this.clienteRepository.findById(rfc);
        if(cliente.isEmpty() || !cliente.isPresent()){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        //VALIDAR SI CLIENTE ESTÁ HABILITADO
        Cliente clienteExistente= this.clienteRepository.findByRfcAndHabilitado(rfc, true);
        if(clienteExistente==null){
            throw new IllegalArgumentException("GIVEN clienteId DOES NOT EXIST");
        }
        
        Comercio comercio= this.comercioRepository.findByRfc(rfc);
        // VALIDAR SI EL CLIENTE ES COMERCIO
        if(comercio==null){
            throw new IllegalArgumentException("ESTE CLIENTE NO ES COMERCIO");
        }
        
        comercio.setCliente(null);
        
        return comercio;
    }
}
