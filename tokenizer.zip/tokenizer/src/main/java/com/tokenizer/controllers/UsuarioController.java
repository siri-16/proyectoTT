/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.controllers;

import com.tokenizer.models.Usuario;
import com.tokenizer.services.UsuarioService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author rirll
 */
@RestController
@RequestMapping("/Clientes/{rfc}/Usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioService usuarioService;
    
    @ResponseBody
    @PostMapping
    public Usuario crearUsuario(@RequestBody Usuario usuario, @PathVariable String rfc) throws Exception{
        return this.usuarioService.crearUsuario(rfc, usuario);
    }
    
    @ResponseBody
    @GetMapping("/")
    public List<Usuario> listarUsuarios(@PathVariable String rfc)throws Exception{
        return this.usuarioService.listarUsuarios();
    }
    
    @ResponseBody
    @GetMapping("/listar")
    public List<Usuario> listarUsuariosId(@PathVariable String rfc)throws Exception{
        return this.usuarioService.listarUsuariosId(rfc);
    }
    
}
