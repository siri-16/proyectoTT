/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.controllers;

import com.tokenizer.models.Cliente;
import com.tokenizer.services.ClienteService;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author rirll
 */
@RestController
@CrossOrigin(origins = "*", methods= {RequestMethod.GET,RequestMethod.POST}, maxAge = 3600)
@RequestMapping("/Clientes")
public class ClienteController {
    
    @Autowired
    private ClienteService clienteService;
    
    @ResponseBody
    @PostMapping
    public Cliente crearCliente(@RequestBody Cliente cliente){
        return this.clienteService.crearCliente(cliente);
    }
    
    @ResponseBody
    @PostMapping("/formulario")
    public Cliente RegistrarCliente(@RequestBody Cliente cliente){
        return this.clienteService.registrarCliente(cliente);
    }
    
    @ResponseBody
    @GetMapping("/listar")
    public ArrayList<Cliente> listarClientes() throws Exception{
        return clienteService.listarClientes();
    }
    
    @ResponseBody
    @GetMapping("/find/{rfc}")
    public Cliente obternerClientePorId(@PathVariable("rfc") String id) throws Exception {
        return this.clienteService.obtenerClientePorId(id);
    }
    
    @ResponseBody
    @PutMapping("/Actualizar/{rfc}")
    public Cliente actualizarCliente(@PathVariable("rfc") String rfc, @RequestBody Cliente clienteActualizado) throws Exception{
        return this.clienteService.actualizarCliente(rfc, clienteActualizado); 
    }
    
    @ResponseBody
    @DeleteMapping("/Eliminar/{rfc}")
    public Cliente eliminarCliente(@PathVariable("rfc") String rfc) throws Exception{
        return this.clienteService.eliminarClientePorId(rfc);
    }
    
    
    /*    @GetMapping("/query")
    public ArrayList<Cliente> obtenerClientesHabilitados(@RequestParam("habilitado") Boolean habilitado){
    return this.clienteService.obtenerClientesHabilitados(habilitado);
    }*/
}
