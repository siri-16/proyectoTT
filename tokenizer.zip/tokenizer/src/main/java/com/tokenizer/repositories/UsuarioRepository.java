/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.repositories;

import com.tokenizer.models.Usuario;
import com.tokenizer.models.UsuarioPK;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author rirll
 */
@Repository
public interface UsuarioRepository extends CrudRepository<Usuario, UsuarioPK> {
    public List<Usuario> findByUsuarioPKRfc(String rfc);
    public Optional<Usuario> findByUsuarioPKNombreUsuario(String nombreUsuario);

    //public Optional<Usuario> findByNombreUsuario(String nombreUsuario);
    //public Usuario findByIdAndNombreUsuario(String rfc, String nombreUsuario);
    
}
