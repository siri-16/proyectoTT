/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.repositories;

import com.tokenizer.models.TokenPAN;
import java.util.Date;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author rirll
 */
@Repository
public interface TokenPanRepository extends CrudRepository<TokenPAN, String>{
    public Optional<TokenPAN> findByTokenPANPKPan(String pan);
    public Optional<TokenPAN> findByToken(String token);
    public TokenPAN findByTokenPANPKRfcAndTokenPANPKPan(String rfc, String pan);
    public Optional<TokenPAN> findByFechaCreacion(Date fechaCreacion);
}
