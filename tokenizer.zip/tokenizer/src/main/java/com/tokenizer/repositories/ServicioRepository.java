/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tokenizer.repositories;

import com.tokenizer.models.Servicio;
import com.tokenizer.models.Usuario;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author rirll
 */
@Repository
public interface ServicioRepository extends CrudRepository<Servicio, String>{
    public Optional<Servicio> findByServicioPKNumeroContrato(String numeroContrato);
    public List<Servicio> findByServicioPKRfc(String rfc);
    
}
